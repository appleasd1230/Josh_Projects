﻿/*====================================================================================================================================================================*/
/*                                                                                                                                                                    */
/* BIS_Desktop JS6 Program ( FileName = ADM_04.js ) Version : 2020.10.27                                                                                              */
/*                                                                                                                                                                    */
/* Copyright (C) 2019-2030 By Root Information Technology (RIT), Inc.                                                                                                 */
/*                                                                                                                                                                    */
/*====================================================================================================================================================================*/

let APP=await import(("./../../JS6/APP/BIS@DesktopAPP.js?Ver="+window.xcVersion));let UNT_PK="";let USR_PK="";

/*====================================================================================================================================================================*/
/*====================================================================================================================================================================*/

window.xmREQ_Config=function(ROL_PKs="") {

for (let i=2;i<TAB_UserRole.rows.length;i++) {

     if (TAB_UserRole.rows[i].cells[0].textContent!=="") { ROL_PKs+=(TAB_UserRole.rows[i].getAttribute("ROL_PK")+"|"); }

} let BIS_ReqS="<ReqS   ID='ADM_04_Config'>"+
               " <Req Name='ADM_04_Config'>"+
               "  <VarS>"+
               "   <Var Name='cUSR_PK'  Data='"+USR_PK +"'/>"+
               "   <Var Name='cROL_PKs' Data='"+ROL_PKs+"'/>"+
               "  </VarS>"+
               " </Req>"+
               "</ReqS>";window.BIS.mREQ_Work(BIS_ReqS);

}

/*====================================================================================================================================================================*/

window.xmREQ_UserRole=function() {

let BIS_ReqS="<ReqS   ID='ADM_04_UserRole'>"+
             " <Req Name='ADM_04_UserRole'>"+
             "  <VarS>"+
             "   <Var Name='cUSR_PK' Data='"+USR_PK+"'/>"+
             "  </VarS>"+
             " </Req>"+
             "</ReqS>";window.BIS.mREQ_Work(BIS_ReqS);

}

/*====================================================================================================================================================================*/
/*====================================================================================================================================================================*/

window.xeBTN_CONFIG=function() { window.BIS.mMBX_Quiz(window.BIS.mConst("--cQuiz_Config"),window.xmREQ_Config); }

/*====================================================================================================================================================================*/

window.xeBTN_EXPORT=function() {

let BIS_ReqS="<ReqS   ID='CUB_A04_Excel'>"+
             " <Req Name='CUB_A04_Excel'>"+
             "  <VarS>"+
             "   <Var Name='cUSR_PK' Data='"+window.xsUSR_PK+"'/>"+
             "  </VarS>"+
             " </Req>"+
             "</ReqS>";window.BIS.mREQ_Work(BIS_ReqS);
}

/*====================================================================================================================================================================*/

window.xeTXI_Seek=function(Text) { window.xeLST_Seek(DIV_Area1,"USR_PK,USR_Name",Text,window.xeLST_User); }

/*====================================================================================================================================================================*/

window.xeLST_Unit=function(LI) {

if (UNT_PK!==LI.getAttribute("UNT_PK")) {

    APP.mBTN_Disabled("*");APP.mTAB_Clean(TAB_UserRole);UNT_PK=LI.getAttribute("UNT_PK");

    if (LI.classList.contains("Expander")===true) { window.xeLST_ExpandONE(DIV_Area1,LI,true); }

} else { window.xeLST_ExpandONE(DIV_Area1,LI,(LI.classList.contains("Expander"))); }

}

/*====================================================================================================================================================================*/

window.xeLST_User=function(LI) { APP.mBTN_Disabled("*");APP.mTAB_Clean(TAB_UserRole);UNT_PK="";USR_PK=LI.getAttribute("USR_PK");window.xmREQ_UserRole(); }

/*====================================================================================================================================================================*/

window.xeREP_Work=function(BIS_ReqS) {

if (BIS_ReqS.getAttribute("ID")==="CUB_A04_Excel") {

    let A=document.createElement('a');
    A.href="data:text/csv;charset=utf-8,\ufeff" +encodeURIComponent(BIS_ReqS.getElementsByTagName("Rep")[0].innerHTML.replaceAll("<br/>","\r\n"));
    A.download="用戶職務資料_"+(new Date().toLocaleString("en-GB").replace(/(\d+)\S(\d+)\S(\d+)\S\s(\d+):(\d+):(\d+)/i,'$3_$2_$1'))+".csv";
    A.click();A.remove();

}

}

/*====================================================================================================================================================================*/
/*====================================================================================================================================================================*/