DROP PROCEDURE ADM_04
GO
CREATE PROCEDURE ADM_04
                 @P_cUSR_PK NVarchar(32)

WITH ENCRYPTION AS

SET NOCOUNT ON

DECLARE @V_cSPCs NVarchar(1024)

SELECT @V_cSPCs='BIS_DesktopUnitUser_LST['+RTRIM(@P_cUSR_PK)+'],ADM_04_Table'

SELECT N'<REP Mode="Block">'

EXEC BIS_DesktopEdit 'CONFIG(N),EXPORT'

EXEC BIS_DesktopView @P_cSPCs = @V_cSPCs

SELECT N'</REP>'

RETURN