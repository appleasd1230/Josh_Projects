DROP PROCEDURE CUB_A04_Excel
GO
CREATE PROCEDURE CUB_A04_Excel
                 @P_cUSR_PK NVarchar(16) = ''

WITH ENCRYPTION AS

SET NOCOUNT ON

DECLARE @V_cUNT_Name   NVarchar(32),
        @V_cUNT_PK     Nvarchar(16),
        @V_dUNT_Date   Datetime,
        @V_cUSR_PK     Nvarchar(16),
        @V_cUSR_Name   NVarchar(32),
        @V_cUSR_Title  NVarchar(32),
        @V_cUSR_Tel    Nvarchar(16),
        @V_cUSR_Role   NVarchar(200),
        @V_cUSR_Tel_O  Nvarchar(16),
        @V_cUNT_Name_O NVarchar(32),
        @V_cUNT_PK_O   Nvarchar(16)
        


SELECT N'���W��,���N��,���إߤ��,�Τ�b��(��s),¾��,�W��(�m�W),�������X,�Τ�¾��,���W��(�e�@),���N��(�e�@),�������X(�e�@)'+'<br/>'

DECLARE User_CUR CURSOR LOCAL FOR
        SELECT T2.cUNT_Name,T2.cUNT_PK,T2.dUNT_Date,T1.cUSR_PK,T1.cUSR_Title,T1.cUSR_Name,T1.cUSR_Tel
        FROM   BIS_User T1
  LEFT  JOIN   BIS_Unit T2 ON (T1.cUNT_FK=T2.cUNT_PK) 
        ORDER BY T2.cUNT_PK,T1.cUSR_PK

OPEN User_CUR 

FETCH NEXT FROM User_CUR INTO @V_cUNT_Name,@V_cUNT_PK,@V_dUNT_Date,@V_cUSR_PK,@V_cUSR_Title,@V_cUSR_Name,@V_cUSR_Tel

WHILE @@FETCH_STATUS = 0 BEGIN

IF @V_cUNT_Name IS NULL SELECT @V_cUNT_Name = ''
IF @V_cUNT_PK IS NULL SELECT @V_cUNT_PK = ''
IF @V_dUNT_Date IS NULL SELECT @V_dUNT_Date = ''


EXEC CUB_UserRoleList
                 @P_cUSR_PK=@V_cUSR_PK,
                 @P_cUser_RoleList=@V_cUSR_Role output


SELECT @V_cUSR_Tel_O  = '',
       @V_cUNT_Name_O = '',
       @V_cUNT_PK_O = ''


SELECT TOP 1 
       @V_cUSR_Tel_O = cUSR_Tel,
       @V_cUNT_Name_O = T2.cUNT_Name,
       @V_cUNT_PK_O = T2.cUNT_PK
FROM BIS_User_log T1
JOIN BIS_Unit T2 ON (T1.cUNT_FK = T2.cUNT_PK)
WHERE T1.cUSR_FK = @V_cUSR_PK 
ORDER BY dUSR_DATE DESC


IF @V_cUSR_Tel_O  IS NULL SELECT @V_cUSR_Tel_O  = ''
IF @V_cUNT_Name_O IS NULL SELECT @V_cUNT_Name_O = ''
IF @V_cUNT_PK_O   IS NULL SELECT @V_cUNT_PK_O = ''


SELECT RTRIM(@V_cUNT_Name) + ',' +
       RTRIM(@V_cUNT_PK) + ',' + 
       CONVERT(char(19),@V_dUNT_Date,120) + ',' + 
       RTRIM(@V_cUSR_PK) + ',' + 
       RTRIM(@V_cUSR_Title) + ',"' + 
       RTRIM(@V_cUSR_Name) + '",' +
       CASE WHEN LEN(RTRIM(@V_cUSR_Tel)) =0 THEN RTRIM(@V_cUSR_Tel) ELSE CONCAT('''',RTRIM(@V_cUSR_Tel)) END + ',"' +
       RTRIM(@V_cUSR_Role)  + '",' +
       RTRIM(@V_cUNT_Name_O)+ ',' +
       RTRIM(@V_cUNT_PK_O)+ ',' +
       RTRIM(@V_cUSR_Tel_O)+'<br/>'

FETCH NEXT FROM User_CUR INTO @V_cUNT_Name,@V_cUNT_PK,@V_dUNT_Date,@V_cUSR_PK,@V_cUSR_Title,@V_cUSR_Name,@V_cUSR_Tel

END

CLOSE User_CUR DEALLOCATE User_CUR

RETURN
