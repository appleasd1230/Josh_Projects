let vPOP_PosX=0,vPOP_PosY=0;
export function mConst(KEY){return String(window.getComputedStyle(document.documentElement).getPropertyValue(KEY)).trim().replace(/"/g,"");}
window.xePOP_Move=function(DIV){
if((event.type==="mousemove")&&(vPOP_PosX>0)){
DIV.style.left=(DIV.offsetLeft-(vPOP_PosX-event.clientX))+"px";vPOP_PosX=event.clientX;
DIV.style.top =(DIV.offsetTop -(vPOP_PosY-event.clientY))+"px";vPOP_PosY=event.clientY;
}else if(event.type==="mousedown"){DIV.style.opacity="0.8";;DIV.style.cursor="move";vPOP_PosX=event.clientX;vPOP_PosY=event.clientY;}
else if(event.type==="mouseup"){DIV.style.opacity="1.0";;DIV.style.cursor="auto";vPOP_PosX=0;            vPOP_PosY=0;}event.stopPropagation();
}
export function mJS6_Load(DOC,JS6){let JS=DOC.createElement("script");JS.type="module";JS.src="JS6/"+JS6+".js?Ver="+window.xcVersion;DOC.head.appendChild(JS);}
export function mCSS_Load(CSS_FileS,FUN_Back,IDX=0){
let CSS=document.createElement("link");CSS.type="text/css";CSS.rel="stylesheet";CSS.href=CSS_FileS[IDX]+"?Ver="+window.xcVersion;document.head.appendChild(CSS);
CSS.onload=function(){if(++IDX<CSS_FileS.length){mCSS_Load(CSS_FileS,FUN_Back,IDX);}else{FUN_Back();}};
}
export function mFILE_Read(FUN_Back,Accept,DataURL=true){
let INP_File=document.createElement("input");INP_File.setAttribute("type","file");INP_File.setAttribute("accept",Accept);document.body.appendChild(INP_File);
INP_File.onchange=function(){
let FILE=new FileReader();if(DataURL===true){FILE.readAsDataURL(INP_File.files[0]);}else{FILE.readAsText(INP_File.files[0]);}
FILE.onload=function(){FUN_Back(FILE.result);};
};INP_File.click();INP_File.remove();
}
const cCFG_Color=["#F22613","#00B5CC","#F7CA18","#9A12B3","#2ABB9B","#EB974E","#67809F",
"#DB0A5B","#1F3A93","#F0FF00","#9F5AFD","#1E824C","#F9690E","#2E3131",
"#96281B","#C5EFF7","#FFFF7E","#DCC6E0","#00E640","#D35400","#BFBFBF",
"#F1828D","#89C4F4","#FFF9DE","#736598","#C8F7C5","#FDE3A7","#95A5A6"];
const cCFG_Chart={type:"",options:{responsive:true,hover:{intersect:true,mode:"nearest"},
tooltips:{intersect:true,mode:"index"},
title:{display:true,fontColor:"#0080C0",fontSize:16,text:""},
legend:{display:true,position:"top"},
scales:{xAxes:[{display:true,stacked:false,scaleLabel:{display:true,labelString:""}}],
yAxes:[{display:true,stacked:false,scaleLabel:{display:true,labelString:""}}]}}};
function nCHART_Draw(CFG,ARY_SETs,ARY_DOTs,TAB_VALs,AREA,LegendDisplay=false){
for(let S=0;S<ARY_SETs.length;S++){
if((CFG.type!="pie")&&(CFG.type!="doughnut")){
if(CFG.type=="polarArea"){
let CFG_Color=(cCFG_Color.join().replace(/\,/g,"80,")+"80").split(",");
CFG.data.datasets.push({label:ARY_SETs[S],backgroundColor:CFG_Color,data:[]});
}else{
let Color=cCFG_Color[S%cCFG_Color.length];
if(CFG.type=="radar"){
CFG.data.datasets.push({label:ARY_SETs[S],backgroundColor:(Color+"80"),borderColor:Color,data:[],fill:true});
}else{CFG.data.datasets.push({label:ARY_SETs[S],backgroundColor:Color,borderColor:Color,data:[],fill:(AREA==true?"origin":false)});}
}
}else{CFG.data.datasets.push({label:ARY_SETs[S],backgroundColor:cCFG_Color,data:[]});}LegendDisplay=((ARY_SETs[S]=="")?LegendDisplay:true);
for(let D=0;D<ARY_DOTs.length;D++){if(S==0){CFG.data.labels.push(ARY_DOTs[D]);}CFG.data.datasets[S].data.push(TAB_VALs[D][S]);}
}CFG.options.legend.display=LegendDisplay;
}
function nCHART_Type(sChart,CFG){
if((sChart=="AREA")||(sChart=="LINE")||(sChart=="VBAR")||(sChart=="HBAR")){
if(sChart=="AREA"){CFG.type="line";}
else if(sChart=="LINE"){CFG.type="line";}
else if(sChart=="VBAR"){CFG.type="bar";}
else if(sChart=="HBAR"){CFG.type="horizontalBar";}
}else if((sChart=="VBARS")||(sChart=="HBARS")){
CFG.options.scales.xAxes[0].stacked=true;CFG.options.scales.yAxes[0].stacked=true;
if(sChart=="VBARS"){CFG.type="bar";}
else if(sChart=="HBARS"){CFG.type="horizontalBar";}
}else{
CFG.options.scales.xAxes[0].display=false;CFG.options.scales.yAxes[0].display=false;
if(sChart=="PIE"){CFG.type="pie";      CFG.options.legend.position="left";}
else if(sChart=="RADAR"){CFG.type="radar";    CFG.options.legend.position="right";}
else if(sChart=="DONUT"){CFG.type="doughnut"; CFG.options.legend.position="left";}
else if(sChart=="POLAR"){CFG.type="polarArea";CFG.options.legend.position="right";}
}
}
function nCHART_Show(CVS){
let ARY_SETs=CVS.getAttribute("SETs").split(",");let sChart=CVS.getAttribute("Chart");
let ARY_DOTs=CVS.getAttribute("DOTs").split(",");let sTitle=CVS.getAttribute("Title");
let ARY_VALs=CVS.getAttribute("VALs").split("|");let TAB_VALs=[];for(let i=0;i<ARY_VALs.length;i++){TAB_VALs.push(ARY_VALs[i].split(",").map(Number));}
let CFG_Chart=JSON.parse(JSON.stringify(cCFG_Chart));
CFG_Chart.options.scales.xAxes[0].scaleLabel.labelString=CVS.getAttribute("XAxis");CFG_Chart.options.title.text=sTitle;
CFG_Chart.options.scales.yAxes[0].scaleLabel.labelString=CVS.getAttribute("YAxis");CFG_Chart.options.title.display=(sTitle!="");nCHART_Type(sChart,CFG_Chart);
let CHART=new Chart(CVS.getContext('2d'),CFG_Chart);nCHART_Draw(CFG_Chart,ARY_SETs,ARY_DOTs,TAB_VALs,(sChart=="AREA"));CHART.update();
}
export function mCHART_Show(CVS_ChartS=null){
if(CVS_ChartS===null){CVS_ChartS=document.getElementsByClassName("CVS_Chart");}
for(let i=0;i<CVS_ChartS.length;i++){
let CVS=CVS_ChartS[i];CVS.setAttribute("Title",window.BIS.mConst(("--"+CVS.id+"-Title")));CVS.setAttribute("SETs",window.BIS.mConst(("--"+CVS.id+"-SETs")));
CVS.setAttribute("XAxis",window.BIS.mConst(("--"+CVS.id+"-XAxis")));
CVS.setAttribute("YAxis",window.BIS.mConst(("--"+CVS.id+"-YAxis")));nCHART_Show(CVS);
}
}
export function mCODE_B64(Code,Encode){
if(Encode===true){return window.btoa(encodeURIComponent(escape(Code)));}
else{return unescape(decodeURIComponent(window.atob(Code)));}
}
const cMP3_Beep="/MP3/BIS_Beep.mp3",cMP3_Clap="/MP3/BIS_Clap.mp3",cMP3_Warn="/MP3/BIS_Warn.mp3";const cColor="#FFFFFF,#CCCCCC";
const cMP3_Bell="/MP3/BIS_Bell.mp3",cMP3_Game="/MP3/BIS_Game.mp3";
const cAudio="<audio class='ADO_Player' id='MED_Play' onerror='window.xeMED_Fail();' controls                         controlsList='nodownload' autoplay type='audio/mpeg'></audio>";
const cVideo="<video class='VDO_Player' id='MED_Play' onerror='window.xeMED_Fail();' controls disablePictureInPicture controlsList='nodownload' autoplay type='video/mp4' ></video>";
function nAudio_Play(SRC,Loop){
let ADO=document.getElementById("ADO_Play");if(ADO!==null){ADO.remove();}
let sADO="<audio "+(Loop===true?"loop":"")+" autoplay id='ADO_Play' style='display:none;'><source src='"+window.xcWebsite+SRC+"' type='audio/mpeg'/></audio>";
document.body.insertAdjacentHTML("beforeend",sADO);ADO_Play.onended=function(){if(Loop===false){document.getElementById("ADO_Play").remove();}}
}
function nMedia_Show(Type,Title,SRC,HTM,Save){
let sADO="<div    id='DIV_ScreenMED' class='DIV_Screen Blur' onclick='event.stopPropagation();'>"+
"<div    class='DIV_Window PLAY' onmousedown='window.xePOP_Move(this);' onmousemove='window.xePOP_Move(this);' onmouseup='window.xePOP_Move(this);'>"+
"<span   class='SPN_Window PLAY' style='background-image:linear-gradient("+cColor+")'>"+Title+"</span>"+
"<img    class='IMG_Window PLAY'/>"+
"<button class='BTN_Window PLAY' id='BTN_WindowQuit' onclick='window.xeMED_Exit();'></button>"+
"<button class='BTN_Window PLAY' id='BTN_WindowWork' onclick='window.xeMED_Save();' style='display:"+((Save===true)?"inline-block":"none")+"'></button>"+
(Type==="Audio"?cAudio:cVideo)+
"<div    class='DIV_Detail PLAY' onmousedown='event.stopPropagation();' onmousemove='event.stopPropagation();' onmouseup='event.stopPropagation();'>"+HTM+
"</div></div></div>";document.body.insertAdjacentHTML("beforeend",sADO);MED_Play.src=SRC;
}
export function mADO_Play(SRC="",Loop=false){
if(SRC===""){ADO_Play.remove();}
else if(SRC==="Beep"){nAudio_Play(cMP3_Beep,Loop);}
else if(SRC==="Bell"){nAudio_Play(cMP3_Bell,Loop);}
else if(SRC==="Clap"){nAudio_Play(cMP3_Clap,Loop);}
else if(SRC==="Game"){nAudio_Play(cMP3_Game,Loop);}
else if(SRC==="Warn"){nAudio_Play(cMP3_Warn,Loop);}else{nAudio_Play(SRC,Loop);}
}
export function mADO_Show(Title,SRC,HTM,Save=false){nMedia_Show("Audio",Title,SRC,HTM,Save);}
export function mVDO_Show(Title,SRC,HTM,Save=false){nMedia_Show("Video",Title,SRC,HTM,Save); MED_Play.parentNode.style.backgroundColor="#000000";}
export async function mCAM_Open(VDO){
if(navigator.mediaDevices!==undefined){
return await navigator.mediaDevices.getUserMedia({audio:false,video:true}).then((Stream)=>{VDO.srcObject=Stream;return true;}).catch(()=>{return false;});
}return false;
}
export function mCAM_Stop(VDO){if(VDO.srcObject!==null){VDO.srcObject.getTracks()[0].stop();}}
export function mCAM_Shot(VDO,CVS){let CTX=CVS.getContext("2d");CTX.save();CTX.scale(-1,1);CTX.drawImage(VDO,0,0,((-1)*CVS.width),CVS.height);CTX.restore();}
window.xeMED_Save=function(){let A=document.createElement('a');A.href=MED_Play.src;A.download=A.href.split("/").pop();A.click();A.remove();}
window.xeMED_Fail=function(){window.BIS.mMBX_Fail(window.BIS.mConst("--cERR_MED_80000"),window.xeMED_Exit);}
window.xeMED_Exit=function(){DIV_ScreenMED.remove();}
export function mPRN_Show(HTM){
let WIN=window.open("about:blank");WIN.document.write.ContentType="text/HTML";
WIN.document.write("<!DOCTYPE html><html lang='"+document.documentElement.lang+"'><head><meta charset='utf-8'/>");
let LinkS=document.getElementsByTagName("link");for(let i=0;i<LinkS.length;i++){WIN.document.write(LinkS[i].outerHTML);}
WIN.document.write("<title>"+window.name+" : Print</title></head><body style='position:relative;display:block;'>"+HTM+"</body></html>");
WIN.document.close();WIN.focus();WIN.onload=function(){WIN.print();WIN.close();}
}
let FUN_MsgboxOK=null,FUN_MsgboxNO=null;
function nMsgbox(Text,Type){
let sMBX="<div  id='DIV_ScreenMBX' class='DIV_Screen Blur' onclick='event.stopPropagation();'>"+
"<div  class='DIV_Msgbox "     +Type+"' onmousedown='window.xePOP_Move(this);' onmousemove='window.xePOP_Move(this);' onmouseup='window.xePOP_Move(this);'>"+
"<span class='SPN_Msgbox Head "+Type+"'></span>"+
"<span class='SPN_Msgbox Time'>"+new Date().toLocaleTimeString("en-GB")+"</span>"+Text.substr(0,90)+
"<button class='BTN_Msgbox "+Type+" OK' onclick='DIV_ScreenMBX.remove();window.xeMBX_Exit(1);'/>"+
((Type==="Quiz")?"<button class='BTN_Msgbox   Quiz   NO' onclick='DIV_ScreenMBX.remove();window.xeMBX_Exit(2);'/>":"")+
"</div></div>";document.body.insertAdjacentHTML("beforeend",sMBX);
}
export function mMBX_Quiz(Text,FUN_OK=null,FUN_NO=null){nMsgbox(Text,"Quiz");FUN_MsgboxOK=FUN_OK;FUN_MsgboxNO=FUN_NO;}
export function mMBX_Done(Text,FUN_OK=null){nMsgbox(Text,"Done");FUN_MsgboxOK=FUN_OK;}
export function mMBX_Fail(Text,FUN_OK=null){nMsgbox(Text,"Fail");FUN_MsgboxOK=FUN_OK;}
export function mMBX_Warn(Text,FUN_OK=null){nMsgbox(Text,"Warn");FUN_MsgboxOK=FUN_OK;}
window.xeMBX_Exit=function(BTN_Msgbox){
if((BTN_Msgbox===1)&&(FUN_MsgboxOK!==null)){FUN_MsgboxOK();}
else if((BTN_Msgbox===2)&&(FUN_MsgboxNO!==null)){FUN_MsgboxNO();}event.stopPropagation();
}
function nOOX_Respond(BIS_RepS){
let Office=BIS_RepS.getElementsByTagName("Office")[0];
if(Office.getAttribute("RET")==="0"){
let LNK=document.createElement('a');LNK.href="data:application/octet-stream;base64,"+Office.innerHTML;
LNK.download=Office.getAttribute("File");LNK.click();LNK.remove();
}else{window.BIS.mMBX_Fail(window.BIS.mConst(Office.innerHTML));}
}
function nOOX_Request(TableS,URL,ERR){
let XHR=new XMLHttpRequest();
XHR.onreadystatechange=function(){
if(this.readyState===4){if(this.status===200){nOOX_Respond(this.responseXML);}else{window.BIS.mMBX_Fail(window.BIS.mConst(ERR));}}
};XHR.open("POST",URL,true);XHR.setRequestHeader("Content-type","application/x-www-form-urlencoded");XHR.send(TableS);
}
function nOOX_TableS(TABs,TableS="<Office>"){
for(let i=0;i<TABs.length;i++){
TableS+="<table><thead><tr>";
for(let C=0;C<TABs[i].rows[0].cells.length;C++){
TableS+="<th>"+window.getComputedStyle(TABs[i].rows[0].cells[C],":before").getPropertyValue("content").replace(/"/g,"")+"</th>";
}TableS+="</tr><tr>";
for(let C=0;C<TABs[i].rows[1].cells.length;C++){
TableS+="<th>"+window.getComputedStyle(TABs[i].rows[1].cells[C],":before").getPropertyValue("content").replace(/"/g,"")+"</th>";
}TableS+="</tr></thead><tbody>";
for(let R=2;R<TABs[i].rows.length;R++){
TableS+="<tr>";for(let C=0;C<TABs[i].rows[R].cells.length;C++){TableS+="<td>"+TABs[i].rows[R].cells[C].textContent+"</td>";}TableS+="</tr>";
}TableS+="</tbody></table>";
}TableS+="</Office>";alert(TableS);return TableS;
}
export function mDOC_Table(TABs){nOOX_Request(nOOX_TableS(TABs),("./../../BIS_Office/BIS_OfficeDOC.aspx"),"--cERR_DOC_10000");}
export function mXLS_Table(TABs){nOOX_Request(nOOX_TableS(TABs),("./../../BIS_Office/BIS_OfficeXLS.aspx"),"--cERR_XLS_10000");}
export function mPPT_Table(TABs){nOOX_Request(nOOX_TableS(TABs),("./../../BIS_Office/BIS_OfficePPT.aspx"),"--cERR_PPT_10000");}
let FUN_WinWork=null,FUN_WinQuit=null;
const ROS_Window=new ResizeObserver(entries=>{let DIV=document.getElementsByClassName("DIV_Window")[0];DIV.style.left="50%";DIV.style.top="50%";});
function nWindow(Title,Color,Style,HTM,Type){
let sWIN="<span   class='SPN_Window "+Style+"' style='background-image:linear-gradient("+Color+")'>"+Title+"</span>"+
"<img    class='IMG_Window "+Style+"'/>"+
"<button class='BTN_Window "+Style+"' id='BTN_WindowQuit' style='display:inline-block' onclick='window.xeWIN_Exit(2);'></button>"+
"<button class='BTN_Window "+Style+"' id='BTN_WindowWork' style='display:none'         onclick='window.xeWIN_Exit(1);'></button>"+
"<div    class='DIV_Detail "+Style+"' onmousedown='event.stopPropagation();"+
"' onmousemove='event.stopPropagation();"+
"' onmouseup='event.stopPropagation();'>"+HTM+"</div>";
if(Type==="Modal"){
sWIN="<div id='DIV_ScreenWIN' class='DIV_Screen Blur'  onclick='event.stopPropagation();'>"+
"<div                    class='DIV_Window "+Style+"' onmousedown='window.xePOP_Move(this);"+
"' onmousemove='window.xePOP_Move(this);"+
"' onmouseup='window.xePOP_Move(this);'>"+sWIN+"</div></div>";
}else if(Type==="Panel"){
sWIN="<div id='DIV_ScreenWIN' class='DIV_Window "+Style+"' onmousedown='window.xePOP_Move(this);"+
"' onmousemove='window.xePOP_Move(this);"+
"' onmouseup='window.xePOP_Move(this);'>"+sWIN+"</div>";
}document.body.insertAdjacentHTML("beforeend",sWIN);ROS_Window.observe(document.getElementsByClassName("DIV_Window")[0]);
}
export function mWIN_Modal(Title,Color,Style,HTM,FUN_Work=null,FUN_Quit=null){nWindow(Title,Color,Style,HTM,"Modal");FUN_WinWork=FUN_Work;FUN_WinQuit=FUN_Quit;}
export function mWIN_Panel(Title,Color,Style,HTM,FUN_Work=null,FUN_Quit=null){nWindow(Title,Color,Style,HTM,"Panel");FUN_WinWork=FUN_Work;FUN_WinQuit=FUN_Quit;}
window.xmWIN_Work=function(ON){BTN_WindowWork.style.display=((ON===true)?"inline-block":"none");}
window.xmWIN_Quit=function(ON){BTN_WindowQuit.style.display=((ON===true)?"inline-block":"none");}
window.xeWIN_Exit=function(BTN_Window=0,Exit=true){
if((BTN_Window===1)&&(FUN_WinWork!==null)){Exit=FUN_WinWork();}
else if((BTN_Window===2)&&(FUN_WinQuit!==null)){Exit=FUN_WinQuit();}if(Exit===true){ROS_Window.disconnect();DIV_ScreenWIN.remove();}event.stopPropagation();
}
export function mWEB_Open(Title,Type,Name,Path,Tab=true,Spec=""){
if(Tab===false){
let W=(screen.width *0.6);let L=(screen.width /2)-(W/2);
let H=(screen.height*0.6);let T=(screen.height/2)-(H/2);Spec="width="+W+",height="+H+",left="+L+",top="+T;
}let WIN=window.open(Path,"_blank",Spec);WIN.name=Name;
WIN.onload=function(){
WIN.document.title=Title;WIN.document.documentElement.lang=document.documentElement.lang;
WIN.xcVersion=window.xcVersion;WIN.xsHostAddr=window.xsHostAddr;WIN.xsUSR_PK=window.xsUSR_PK;
WIN.xcGateway=window.xcGateway;WIN.xsDeskAddr=window.xsDeskAddr;
WIN.xcWebsite=window.xcWebsite;
if(Type==="WEB"){window.BIS.mJS6_Load(WIN.document,Name);}
}
}
let vREQ_Timeout=0,vREQ_Seconds=0;
function nREQ_Time(){
if(vREQ_Seconds===0){window.clearTimeout(vREQ_Timeout);DIV_ScreenREQ.remove();return;}
else if(vREQ_Seconds===1){document.body.insertAdjacentHTML("beforeend","<div id='DIV_ScreenREQ' class='DIV_Screen'/>");}
else if(vREQ_Seconds===3){DIV_ScreenREQ.innerHTML="<img id='IMG_Request'/><span id='SPN_Second'>00:03</span>";DIV_ScreenREQ.classList.add("Busy");}
else if(vREQ_Seconds > 3){SPN_Second.textContent=('0'+parseInt(vREQ_Seconds/60)).substr(-2,2)+':'+('0'+parseInt(vREQ_Seconds%60)).substr(-2,2);}
++vREQ_Seconds;vREQ_Timeout=window.setTimeout(nREQ_Time,1000);
}
function nREQ_Work(BIS_RepS,FUN_Succ,FUN_Fail){
if(BIS_RepS.documentElement.getAttribute("RET")==="0"){
let REPs=BIS_RepS.getElementsByTagName("Rep");
for(let i=0;i<REPs.length;i++){
if(REPs[i].getAttribute("RET")!="0"){
let MSG=REPs[i].getAttribute("MSG");
if(MSG.substr(0,2)==="--"){FUN_Fail(MSG);}else{FUN_Fail((MSG+"<br>Error [ "+REPs[i].getAttribute("RET")+" ]"));}return;
}
}FUN_Succ(BIS_RepS.getElementsByTagName("RepS")[0]);
}else if(BIS_RepS.documentElement.getAttribute("RET")==="91000"){window.BIS.mREP_Fail("--cERR_REQ_91000");
}else if(BIS_RepS.documentElement.getAttribute("RET")==="92000"){window.BIS.mREP_Fail("--cERR_REQ_92000");}
}
export function mREQ_Work(BIS_ReqS,FUN_Succ=null,FUN_Fail=null,Time=true){
if(FUN_Succ===null){FUN_Succ=function(BIS_RepS){window.BIS.mREP_Work(BIS_RepS);}}
if(FUN_Fail===null){FUN_Fail=function(ERR_Text){window.BIS.mREP_Fail(ERR_Text);}}
let XHR=new XMLHttpRequest();if(Time===true){vREQ_Seconds=1;nREQ_Time();}BIS_ReqS=BIS_ReqS.replace(/&/g,"&amp;");
XHR.onreadystatechange=function(){
if(this.readyState===4){
if(Time===true){vREQ_Seconds=0;nREQ_Time();}
if(this.status===200){
if(this.responseXML!==null){nREQ_Work(this.responseXML,FUN_Succ,FUN_Fail);}else{window.BIS.mREP_Fail("--cERR_REQ_93000");}
}else{window.BIS.mREP_Fail("--cERR_REQ_90000");}
}
};XHR.open("POST",window.xcGateway,true);XHR.setRequestHeader("Content-type","application/x-www-form-urlencoded");XHR.send("<BIS>"+BIS_ReqS+"</BIS>");
}
const ROS_Area=new ResizeObserver(entries=>{
let DIVs=document.getElementsByClassName("DIV_Area");let W=0;
for(let i=0;i<(DIVs.length-1);i++){W+=DIVs[i].offsetWidth;}DIVs[DIVs.length-1].style.width=DIV_View.offsetWidth-W+"px";
});
function nREP_Setup(REP){window[REP.getAttribute("Name")]=REP.getAttribute("Data");}
function nREP_Scene(REP){document.body.insertAdjacentHTML("beforeend",REP.innerHTML);}
function nREP_Block(REP){
document.body.insertAdjacentHTML("beforeend",REP.innerHTML);let DIVs=document.getElementsByClassName("DIV_Area");
for(let i=0;i<(DIVs.length-1);i++){ROS_Area.observe(DIVs[i]);}ROS_Area.observe(DIV_View);
}
function nREP_Phase(REP){
document.body.insertAdjacentHTML("beforeend",REP.innerHTML);
}
function nREP_Renew(REP){
let ELMs=REP.getElementsByTagName("*");
for(let i=0;i<ELMs.length;i++){
let ELM=document.getElementById(ELMs[i].id);
if(ELM!==null){
if(REP.getAttribute("Type")==="Head"){ELM.innerHTML=ELMs[i].innerHTML+ELM.innerHTML;}
else if(REP.getAttribute("Type")==="Tail"){ELM.innerHTML=ELM.innerHTML+ELMs[i].innerHTML;}
else if(REP.getAttribute("Type")==="Vary"){ELM.innerHTML=ELMs[i].innerHTML;}
else if(REP.getAttribute("Type")==="Swap"){ELM.outerHTML=ELMs[i].outerHTML;}
}
}
}
function nREP_Popup(REP){
let Title=REP.getAttribute("Title");Title=(Title===null?window.BIS.mConst("--cPopup_Ttile"):(Title.substr(0,2)==="--"?window.BIS.mConst(Title):Title));
let FUN_Work=(REP.getAttribute("FUN_Work")===null?null:window[REP.getAttribute("FUN_Work")]);
let FUN_Quit=(REP.getAttribute("FUN_Quit")===null?null:window[REP.getAttribute("FUN_Quit")]);
if(REP.getAttribute("Type")==="Modal"){window.BIS.mWIN_Modal(Title,"#FFFFFF,#CCCCCC","EDIT",REP.innerHTML,FUN_Work,FUN_Quit);}
else if(REP.getAttribute("Type")==="Panel"){window.BIS.mWIN_Panel(Title,"#FFFFFF,#CCCCCC","EDIT",REP.innerHTML,FUN_Work,FUN_Quit);}
window.xmWIN_Work(REP.getAttribute("BTN_Work")==="Y");window.xmWIN_Quit(REP.getAttribute("BTN_Quit")==="Y");
}
function nREP_Media(REP){
let Title=REP.getAttribute("Title");Title=(Title===null?window.BIS.mConst("--cPopup_Ttile"):(Title.substr(0,2)==="--"?window.BIS.mConst(Title):Title));
if(REP.getAttribute("Type")==="Audio"){window.BIS.mADO_Show(Title,REP.getAttribute("SRC"),REP.innerHTML,(REP.getAttribute("Title")==="True"));}
else if(REP.getAttribute("Type")==="Video"){window.BIS.mVDO_Show(Title,REP.getAttribute("SRC"),REP.innerHTML,(REP.getAttribute("Title")==="True"));}
}
function nREP_Alert(REP){
let Text=REP.getAttribute("Text");if(Text.substr(0,2)==="--"){Text=window.BIS.mConst(Text);}
let FUN_OK=(REP.getAttribute("FUN_OK")===null?null:window[REP.getAttribute("FUN_OK")]);
let FUN_NO=(REP.getAttribute("FUN_NO")===null?null:window[REP.getAttribute("FUN_NO")]);
if(REP.getAttribute("Type")==="Quiz"){window.BIS.mMBX_Quiz(Text,FUN_OK,FUN_NO);}
else if(REP.getAttribute("Type")==="Done"){window.BIS.mMBX_Done(Text,FUN_OK);}
else if(REP.getAttribute("Type")==="Fail"){window.BIS.mMBX_Fail(Text,FUN_OK);}
else if(REP.getAttribute("Type")==="Warn"){window.BIS.mMBX_Warn(Text,FUN_OK);}
}
export function mREP_Work(BIS_RepS){
let REPs=BIS_RepS.getElementsByTagName("REP");
for(let i=0;i<REPs.length;i++){
if(REPs[i].getAttribute("Mode")==="Setup"){nREP_Setup(REPs[i]);}
else if(REPs[i].getAttribute("Mode")==="Scene"){nREP_Scene(REPs[i]);}
else if(REPs[i].getAttribute("Mode")==="Block"){nREP_Block(REPs[i]);}
else if(REPs[i].getAttribute("Mode")==="Phase"){nREP_Phase(REPs[i]);}
else if(REPs[i].getAttribute("Mode")==="Renew"){nREP_Renew(REPs[i]);}
else if(REPs[i].getAttribute("Mode")==="Popup"){nREP_Popup(REPs[i]);}
else if(REPs[i].getAttribute("Mode")==="Media"){nREP_Media(REPs[i]);}
else if(REPs[i].getAttribute("Mode")==="Alert"){nREP_Alert(REPs[i]);}
}if(window.xeREP_Work!==undefined){window.xeREP_Work(BIS_RepS,BIS_RepS.getAttribute("ID"));}
}
export function mREP_Fail(ERR_Text){window.BIS.mMBX_Fail(((ERR_Text.substr(0,2)==="--")?window.BIS.mConst(ERR_Text):ERR_Text));}
const cTIP_Timeout=2000;let TIP_Timeout=null;
function nTIP_Kill(){
if(TIP_Timeout!=null){
window.clearTimeout(TIP_Timeout);TIP_Timeout=null;
let TIP=document.getElementsByClassName("SPN_Tooltip")[0];if(TIP!==undefined){TIP.remove();}
}
}
export function mTIP_Show(OBJ,Side,Text=window.BIS.mConst("--cTIP_Null"),OffsetX=0,OffsetY=5){
let RECT=OBJ.getBoundingClientRect();nTIP_Kill();TIP_Timeout=window.setTimeout(nTIP_Kill,cTIP_Timeout);
if(Side==="B"){
document.body.insertAdjacentHTML("beforeend","<span id='SPN_TooltipB' class='SPN_Tooltip'>"+Text+"<br><span id='SPN_TooltipB-Arrow'>▼</span></span>");
SPN_TooltipB.style.left=RECT.left+OffsetX+"px";SPN_TooltipB.style.top=RECT.top-OffsetY+"px";
}else if(Side==="T"){
document.body.insertAdjacentHTML("beforeend","<span id='SPN_TooltipT' class='SPN_Tooltip'>"+Text+"<br><span id='SPN_TooltipT-Arrow'>▲</span></span>");
SPN_TooltipT.style.left=RECT.left+OffsetX+"px";SPN_TooltipT.style.top=RECT.top+RECT.height+OffsetY+"px";
}OBJ.focus();
}
window.xeLST_Seek=function(DIV,ATB_Name,ATB_Seek,FUN_Seek=null){
if(ATB_Seek===""){return undefined;}let LIs=DIV.getElementsByTagName("li");ATB_Seek=ATB_Seek.trim().toUpperCase();
for(let i=0;i<LIs.length;i++){
let ATB_NameS=ATB_Name.split(",");
for(let j=0;j<ATB_NameS.length;j++){
let ATB_Data=LIs[i].getAttribute(ATB_NameS[j]);if(ATB_Data===null){continue;}
if(ATB_Data.toUpperCase()===ATB_Seek){
if(LIs[i].style.display==="none"){window.xeLST_ExpandALL(DIV,true);}window.xeLST_Select(DIV,LIs[i]);LIs[i].scrollIntoView(false);
if(FUN_Seek!==null){FUN_Seek(LIs[i]);}return LIs[i];
}
}
}return undefined;
}
window.xeLST_Mask=function(DIV,Class,ATB_Name,ATB_Mask){
let LIs=DIV.getElementsByTagName("li");ATB_Mask=ATB_Mask.trim().toUpperCase();let Display="none";
for(let i=0;i<LIs.length;i++){
if(ATB_Mask!==""){
if(LIs[i].classList.contains(Class)===true){
let ATB_NameS=ATB_Name.split(",");
for(let j=0;j<ATB_NameS.length;j++){
let ATB_Data=LIs[i].getAttribute(ATB_NameS[j]);
if(ATB_Data!==null){if(ATB_Data.toUpperCase().indexOf(ATB_Mask)>=0){Display="block";break;}}
}
}LIs[i].style.display=Display;Display="none";
}else{LIs[i].style.display="block";}
}
}
window.xeLST_ExpandALL=function(DIV,Expand){
let LIs=DIV.getElementsByTagName("li");let Display=((Expand===true)?"block":"none");
for(let i=0;i<LIs.length;i++){if(parseInt(LIs[i].style.paddingLeft)>0){LIs[i].style.display=Display;}LIs[i].classList.remove("Expander");}
}
window.xeLST_ExpandONE=function(DIV,LI,Expand=null){
let LIs=DIV.getElementsByTagName("li");let IDX=(Array.prototype.indexOf.call(LIs,LI)+1);let PaddingLeft=parseInt(LI.style.paddingLeft);let Display="block";let Count=0;
for(let i=IDX;i<LIs.length;i++){
if(PaddingLeft>=parseInt(LIs[i].style.paddingLeft)){break;}LIs[i].classList.remove("Expander");Count++;
Display=((Display==="none")?"none":((Expand===true)?"block":((Expand===false)?"none":((LIs[i].style.display==="none")?"block":"none"))));
LIs[i].style.display=Display;
}if(Count>0){if(Expand===true){LI.classList.remove("Expander");}else if(Expand===false){LI.classList.add("Expander");}}
}
window.xeLST_Select=function(DIV,LI){
let LIs=DIV.getElementsByClassName("Selected");
for(let i=0;i<LIs.length;i++){LIs[i].classList.remove("Selected");}LI.classList.add("Selected");return LI;
}
window.xeLST_Selected=function(DIV){let LIs=DIV.getElementsByClassName("Selected");if(LIs.length>0){return LIs[0];}return undefined;}
const cTAB_SortASC=" ▲",cTAB_SortDSC=" ▼";
export function mTAB_Focus(TABs){
for(let i=0;i<TABs.length;i++){
for(let R=0;R<TABs[i].rows.length;R++){
for(let C=0;C<TABs[i].rows[R].cells.length;C++){
if(TABs[i].rows[R].cells[C].getAttribute("contenteditable")==="true"){TABs[i].rows[R].cells[C].focus();return;}
}
}
}
}
export function mTAB_Valid(TABs){
for(let i=0;i<TABs.length;i++){
for(let R=0;R<TABs[i].rows.length;R++){
for(let C=0;C<TABs[i].rows[R].cells.length;C++){
if(TABs[i].rows[R].cells[C].classList.contains("Must")===true){
if(TABs[i].rows[R].cells[1].textContent.trim()===""){window.BIS.mTIP_Show(TABs[i].rows[R].cells[C],"B");return false;}
}
}
}
}return true;
}
export function mTAB_Seek(TABs,TXT,ROW=2){
TXT=TXT.trim().toUpperCase();
for(let i=0;i<TABs.length;i++){
for(let R=ROW;R<TABs[i].rows.length;R++){
for(let C=0;C<TABs[i].rows[R].cells.length;C++){
if(TABs[i].rows[R].cells[C].textContent.toUpperCase().indexOf(TXT)>=0){window.xeTR_Select(TABs[i].rows[R],true,ROW);return TABs[i].rows[R];}
}
}
}return undefined;
}
export function mTAB_Mask(TABs,TXT,ROW=2,Display="none"){
TXT=TXT.trim().toUpperCase();
for(let i=0;i<TABs.length;i++){
for(let R=ROW;R<TABs[i].rows.length;R++){
if(TXT!==""){
for(let C=0;C<TABs[i].rows[R].cells.length;C++){
if(TABs[i].rows[R].cells[C].textContent.toUpperCase().indexOf(TXT)>=0){Display="table-row";break;}
}TABs[i].rows[R].style.display=Display;Display="none";
}else{TABs[i].rows[R].style.display="table-row";}
}
}
}
window.xeTAB_Sort=function(TH,Col,Type){
let TAB=TH.parentNode.parentNode.parentNode;let TBODY=TAB.tBodies[0];
let SortASC=(TAB.rows[1].cells[Col].innerHTML.indexOf(cTAB_SortASC)<0);let ARY_Data=[];
for(let R=0;R<TBODY.rows.length;R++){ARY_Data[R]=TBODY.rows[R];}TBODY.innerHTML="";
for(let C=0;C<TAB.rows[1].cells.length;C++){TAB.rows[1].cells[C].innerHTML=TAB.rows[1].cells[C].innerHTML.replace(cTAB_SortASC,"").replace(cTAB_SortDSC,"");}
if(Type==="C"){
if(SortASC===true){ARY_Data.sort(function(TR1,TR2){return(TR1.cells[Col].innerHTML>=TR2.cells[Col].innerHTML?1:-1);});}
else{ARY_Data.sort(function(TR1,TR2){return(TR2.cells[Col].innerHTML>=TR1.cells[Col].innerHTML?1:-1);});}
}else if(Type==="N"){
if(SortASC===true){ARY_Data.sort(function(TR1,TR2){return parseInt(TR1.cells[Col].innerHTML)-parseInt(TR2.cells[Col].innerHTML);});}
else{ARY_Data.sort(function(TR1,TR2){return parseInt(TR2.cells[Col].innerHTML)-parseInt(TR1.cells[Col].innerHTML);});}
}for(let A=0;A<ARY_Data.length;A++){TBODY.appendChild(ARY_Data[A]);}TH.innerHTML+=(SortASC===true?cTAB_SortASC:cTAB_SortDSC);
}
window.xeTAB_Edit=function(TD,KeyCode){
if(TD.getAttribute("contenteditable")==="true"){
if(TD.textContent.length<parseInt(TD.getAttribute("Max"))){
if(TD.getAttribute("Type")=="ASC"){return(((KeyCode>=65)&&(KeyCode<=90))||((KeyCode>=97)&&(KeyCode<=122))||((KeyCode>=48)&&(KeyCode<=57)));}
else if(TD.getAttribute("Type")=="DTM"){return(((KeyCode>=48)&&(KeyCode<=57))||(KeyCode==32)||(KeyCode==45)||(KeyCode==58));}
else if(TD.getAttribute("Type")=="IPA"){return(((KeyCode>=48)&&(KeyCode<=57))||(KeyCode==42)||(KeyCode==46));}
else if(TD.getAttribute("Type")=="NUM"){return(((KeyCode>=48)&&(KeyCode<=57))||(KeyCode==46));}
else if(TD.getAttribute("Type")=="DAT"){return(((KeyCode>=48)&&(KeyCode<=57))||(KeyCode==45));}
else if(TD.getAttribute("Type")=="TIM"){return(((KeyCode>=48)&&(KeyCode<=57))||(KeyCode==58));}
else if(TD.getAttribute("Type")=="INT"){return((KeyCode>=48)&&(KeyCode<=57));}
else if(TD.getAttribute("Type")=="TXI"){return(KeyCode!==13);}
else if(TD.getAttribute("Type")=="TXT"){return true;}
}window.BIS.mTIP_Show(TD,"B",window.BIS.mConst("--cTIP_Edit"));return false;
}return true;
}
window.xeTAB_Paste=function(TD){
event.preventDefault();let TXT=event.clipboardData.getData("Text");
if((TD.textContent.length+TXT.length)<=parseInt(TD.getAttribute("Max"))){
document.execCommand("insertText",false,TXT);
}else{window.BIS.mTIP_Show(TD,"B",window.BIS.mConst("--cTIP_Edit"));}
}
window.xeTAB_Display=function(DIV,TAB){
let TABs=DIV.getElementsByTagName("table");
for(let i=0;i<TABs.length;i++){TABs[i].style.display="none";}TAB.style.display="table";
}
window.xeTAB_Expand=function(TAB,Expand,ROW=2){
let Display=(Expand===true?"table-row":"none");
for(let i=ROW;i<TAB.rows.length;i++){
if(TAB.rows[i].cells[0].classList.contains("TC_Expand")===true){
if((Expand===true)&&(TAB.rows[i].cells[0].classList.contains("OF")===true)){
TAB.rows[i].cells[0].classList.remove("OF");TAB.rows[i].cells[0].classList.add("ON");
}else if((Expand===false)&&(TAB.rows[i].cells[0].classList.contains("ON")===true)){
TAB.rows[i].cells[0].classList.remove("ON");TAB.rows[i].cells[0].classList.add("OF");
}
}else{TAB.rows[i].style.display=Display;}
}
}
window.xeTAB_Select=function(DIV,TAB){
let TABs=DIV.getElementsByTagName("table");
for(let i=0;i<TABs.length;i++){TABs[i].classList.remove("Selected");}TAB.classList.add("Selected");return TAB;
}
window.xeTAB_Selected=function(DIV){
let TABs=DIV.getElementsByTagName("table");
for(let i=0;i<TABs.length;i++){if(TABs[i].classList.contains("Selected")===true){return TABs[i];}}return undefined;
}
window.xeTR_Delete=function(TR,Name){let TRs=document.getElementsByName(Name);for(let i=(TRs.length-1);i>=0;i--){TRs[i].remove();}TR.remove();}
window.xeTR_Expand=function(TR,Name,Display=""){
if(TR.cells[0].classList.contains("ON")===true){
TR.cells[0].classList.remove("ON");TR.cells[0].classList.add("OF");Display="none";
}else{
TR.cells[0].classList.remove("OF");TR.cells[0].classList.add("ON");Display="table-row";
}let TRs=document.getElementsByName(Name);for(let i=0;i<TRs.length;i++){TRs[i].style.display=Display;}
}
window.xeTR_Select=function(TR,Scroll=false){
let TAB=TR.parentNode.parentNode;if(Scroll===true){TR.scrollIntoView(false);}let TRs=TAB.getElementsByClassName("Selected");
for(let i=0;i<TRs.length;i++){TRs[i].classList.remove("Selected");}TR.classList.add("Selected");return TR;
}
window.xeTR_Selected=function(TAB){let TRs=TAB.getElementsByClassName("Selected");if(TRs.length>0){return TRs[0];}return undefined;}
window.xeBTN_Select=function(DIV,BTN){
let BTNs=DIV.getElementsByClassName("Selected");
for(let i=0;i<BTNs.length;i++){BTNs[i].classList.remove("Selected");}BTN.classList.add("Selected");return BTN;
}
window.xeBTN_Selected=function(DIV){let BTNs=DIV.getElementsByClassName("Selected");if(BTNs.length>0){return BTNs[0];}return undefined;}
export function mCVS_Image(CVS,DataURL){
let IMG=new Image();IMG.src=DataURL;CVS.getContext("2d").clearRect(0,0,CVS.width,CVS.height);
IMG.onload=function(){
let X_Offset=((IMG.width>=CVS.width)?0:((CVS.width-IMG.width)/2));let Y_Offset=((IMG.height>=CVS.height)?0:((CVS.height-IMG.height)/2));
CVS.getContext('2d').drawImage(IMG,X_Offset,Y_Offset);
};
}
